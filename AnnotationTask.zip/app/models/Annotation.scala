package models

import javax.persistence._
import java.sql.Timestamp
import play.db.ebean.Model
import scala.collection.JavaConversions._

/**
 * Created by Aldo on 04/08/14.
 */
object Annotation {
  def findByID(id: Int): Annotation = find.byId(id)

  def getAnnotationByUserID(idUser: Long): List[Annotation] = find.where.eq("idUser", idUser).findList.toList

  var find: Model.Finder[Int, Annotation] = new Model.Finder[Int, Annotation](classOf[Int], classOf[Annotation])
}

@Table(uniqueConstraints = Array(new UniqueConstraint(columnNames = Array("idSeed", "idEmbryon", "idUser")))) @Entity class Annotation  extends Model {
  @Id var id: Int = 0
  @OneToOne @JoinColumn(name="idSeed", referencedColumnName = "id") var seed: Seed = null
  @OneToOne @JoinColumn(name="idEmbryon", referencedColumnName = "id") var embryon: Embryon = null
  @OneToOne @JoinColumn(name="idUser", referencedColumnName = "id") var user: User = null
  @OneToOne @JoinColumn(name="idCategory", referencedColumnName = "id") var category: Category = null
  @Column(nullable = false, columnDefinition="TIMESTAMP DEFAULT CURRENT_TIMESTAMP") var dateCreation: Timestamp = null
}
