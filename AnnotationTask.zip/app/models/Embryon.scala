package models

import javax.persistence._
import java.sql.Timestamp
import play.db.ebean.Model
import scala.collection.JavaConversions._
import com.avaje.ebean.{SqlRow, Ebean}

/**
 * Created by Aldo on 04/08/14.
 */

object Embryon {

  def getAll: List[Embryon] = find.all.toList

  def findByID(idEmbrion: String, idSeed: String): Embryon = find.where.eq("id_embryon", idEmbrion).eq("idSeed", idSeed).findUnique

  def findByID(id:Int): Embryon = find.byId(id)


  def getRandomEmbryonToAnnotate(idUser: Long): Embryon = {
    val sqlEmbryonToAnnotate = Ebean.createSqlQuery("SELECT id FROM (SELECT id, embryon.idSeed FROM embryon LEFT JOIN (SELECT idSeed FROM annotation WHERE idUser=:idUser AND idCategory=\"Garbage\") as garbageSeed ON embryon.idSeed=garbageSeed.idSeed WHERE garbageSeed.idSeed Is NULL) as fEmbryon LEFT JOIN (SELECT idSeed, idEmbryon FROM annotation where idUser=:idUser) as annotated ON fEmbryon.idSeed=annotated.idSeed AND fEmbryon.id=annotated.idEmbryon WHERE annotated.idSeed Is Null ORDER BY RAND() LIMIT 1")
    sqlEmbryonToAnnotate.setParameter("idUser", idUser)
    val sqlResult = sqlEmbryonToAnnotate.findList.toList
    if(sqlResult.isEmpty) null else {
      val embryonId:Int = sqlResult.head.getInteger("id").toInt
      findByID(embryonId)
    }
  }

  var find: Model.Finder[Int, Embryon] = new Model.Finder[Int, Embryon](classOf[Int], classOf[Embryon])
}

@Table(uniqueConstraints = Array(new UniqueConstraint(columnNames = Array("id_embryon", "idSeed")))) @Entity class Embryon extends Model{
  @Id var id:Int = 0
  @Column(nullable = false) var idEmbryon: String = null
  @OneToOne @JoinColumn(name="idSeed", referencedColumnName = "id") var seed: Seed = null
  @Column(nullable = false, columnDefinition="TIMESTAMP DEFAULT CURRENT_TIMESTAMP") var dateCreation: Timestamp = null
}
