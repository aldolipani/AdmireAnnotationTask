package models

import javax.persistence._
import java.sql.Timestamp
import play.db.ebean.Model

/**
 * Created by Aldo on 04/08/14.
 */
object SeedBlock {

}

@Entity class SeedBlock extends Model {
  @Id var id: String = ""
  @OneToOne @JoinColumn(name="idUser", referencedColumnName = "id") var user: User = null
  @Column(nullable = false, columnDefinition="TIMESTAMP DEFAULT CURRENT_TIMESTAMP") var dateCreation: Timestamp = null
}
