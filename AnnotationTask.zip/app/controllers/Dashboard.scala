package controllers

import models._
import play.api.mvc.{Controller, Action, Security}
import controllers.searchEngine.{Document, Engine}
import scala.util.Random
import controllers.semanticVectors.RandomIndexSearch


/**
 * Created by Aldo on 04/08/14.
 */
object Dashboard extends Controller with Secured{

  def initializeDatabase {
    List("None", "Garbage", "Skip", "Challenge", "Campaign", "Measure", "Event", "Experiment", "Task", "Run", "Score", "TestCollection", "Collection", "Topic", "Topics", "Groundtruth")
      .filter(Category.findByID(_)==null).map(cat => {
      val category = new Category
      category.id = cat
      category.save})

    List("MAP")
      .filter(Seed.findByID(_)==null).map(s => {
      val seed = new Seed
      seed.id = s
      seed.save
      generateEmbryons(seed)
    })
  }

  def time[A](a: => A) = {
       val now = System.nanoTime
       val result = a
       val micros = (System.nanoTime - now) / 1000
       println("%d microseconds".format(micros))
       result
  }

  def index = withAuth { username  => implicit request =>
    val embryon = (getRandomEmbryon(username))
    (if(embryon == null){ // check if embryons has to be initialized
      if(Embryon.getAll.isEmpty){
        initializeDatabase
        if(Embryon.getAll.nonEmpty){
          val embryon = getRandomEmbryon(username)
          val engine = new Engine
          val doc = engine.getDocumentByID(embryon.idEmbryon) //@(user: User, seed: Seed, embryon: Embryon, doc: controllers.searchEngine.Document, categories: List[Category])
          Ok(
            views.html.dashboard.index.render(
              User.findByEmail(username),
              embryon.seed,
              embryon,
              doc,
              doc.getSnippet,
              Category.getAll))
        }else {
          Ok(views.html.dashboard.message.render(User.findByEmail(username),
            "No seeds present!"))
        }
      }else{
        Ok(views.html.dashboard.message.render(User.findByEmail(username),
          "Congratulations, you have done everything could be possibly done!\n Come later maybe you will find others!"))
      }
    }else{
      val engine = new Engine
      val doc = engine.getDocumentByID(embryon.idEmbryon) //@(user: User, seed: Seed, embryon: Embryon, doc: controllers.searchEngine.Document, categories: List[Category])
      Ok(
        views.html.dashboard.index.render(
          User.findByEmail(username),
          embryon.seed,
          embryon,
          doc,
          doc.getSnippet,
          Category.getAll))
    })

  }

  def generateEmbryons(seed: Seed) = {
    val engine = new Engine;
    val docs = engine.search(seed.id.toLowerCase)
    println("GenerateEmbryon: docs " + docs.size)
    docs.map(doc => {
      val embryon = new Embryon
      embryon.idEmbryon = doc.id
      embryon.seed = seed
      embryon.save
    })

  }

  def getRandomEmbryon(username: String): Embryon = {
    val user = (User.findByEmail(username))
    Embryon.getRandomEmbryonToAnnotate(user.id)
  }

  def generateSeedAndEmbryon(str:String) = {
    val ris = new RandomIndexSearch
    ris.search(str).filter(Seed.findByID(_)==null).map(ns =>{
      val seed = new Seed
      seed.id = ns
      seed.save
      println(str)
      time(generateEmbryons(seed))
    })
  }

  def annotate(idSeed:String, idEmbryon: String, idCat: String) = withAuth{ username => implicit request =>
    if(idCat != "Skip"){
      val annotation = new Annotation
      annotation.seed = Seed.findByID(idSeed)
      annotation.embryon = Embryon.findByID(idEmbryon, idSeed)
      annotation.category = Category.findByID(idCat)
      annotation.user = User.findByEmail(username)
      annotation.save

      if(idCat != "Garbage" && idCat != "None") generateSeedAndEmbryon(idSeed)
    }


    /*val embryon = getRandomEmbryon(username)
    val engine = new Engine
    val doc = engine.getDocumentByID(embryon.idEmbryon)
      */
    /*Ok(
      views.html.dashboard.index.render(
        User.findByEmail(username),
        embryon.seed,
        embryon,
        doc,
        doc.getSnippet,
        Category.getAll:::getExtraCategories))*/
    Redirect("/dashboard", MOVED_PERMANENTLY)
  }


}


