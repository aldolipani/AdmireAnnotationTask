package controllers

import play.api._
import play.api.mvc._
import models.User
import play.Logger

import play.api.mvc.Result
import play.i18n.Messages
import play.mvc.Result
import play.data.validation.Constraints
import play.api.mvc.Result
import play.api.data._
import play.api.data.Forms._

object Application extends Controller{

  def goHome = Redirect(routes.Application.index)
  def goDashboard = Redirect(routes.Dashboard.index)
                 var message = ""
  def index = Action { request =>
    val email = request.session.get(Security.username)
    if (email != None) {
      val user: User = User.findByEmail(email.get)
      if (user != null) {
        Redirect(routes.Dashboard.index)
      } else {
        Logger.debug("Invalid session credentials")
        Ok(views.html.index.render(registerForm, loginForm, message))
      }
    }else{
      Ok(views.html.index.render(registerForm, loginForm, message))
    }
  }

  def authenticate = Action { implicit request =>
     loginForm.bindFromRequest.fold(
      formWithErrors => BadRequest(views.html.index.render(registerForm, formWithErrors, "")),
      user => goDashboard.withSession(Security.username -> user._1))}

  /**
   * Logout and clean the session.
   *
   * @return Index page
   */
  def logout = Action { implicit request =>
    Redirect("/").withNewSession
  }

  val loginForm = Form(
    tuple(
      "email" -> nonEmptyText,
      "password" -> nonEmptyText
    ).verifying(Messages.get("invalid.user.or.password"), fields => fields match {
      case (u, p) => User.authenticate(u, p) != null
    })
  )

  val registerForm = Form(
    tuple(
      "email" -> nonEmptyText,
      "password" -> nonEmptyText
    ).verifying(Messages.get("error.email.already.exist"), fields => fields match {
      case (u, p) => User.findByEmail(u) == null
    })
  )
}
