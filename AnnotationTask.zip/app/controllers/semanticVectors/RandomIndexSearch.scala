package controllers.semanticVectors

/**
 * Created by Aldo on 05/08/14.
 */

import pitt.search.semanticvectors.{FlagConfig, Search, SearchResult}
import org.apache.lucene.util.Version
import play.api.Play
             import scala.collection.JavaConversions._
object RandomIndexSearch{


}

class RandomIndexSearch {
  val pathIndex = Play.current.configuration.getString("randomindexing.index").get
  val nhits = 1000;


  def search(str: String): List[String] = {
    val flagConfig = FlagConfig.parseFlagsFromString("-queryvectorfile " + pathIndex+"/termtermvectors.bin " + str);
    val results = Search.runSearch(flagConfig).toList

    if (results.nonEmpty) {
      results.map(r => {
        r.getObjectVector.getObject.toString
      })
    } else {
      Nil
    }
  }

}
