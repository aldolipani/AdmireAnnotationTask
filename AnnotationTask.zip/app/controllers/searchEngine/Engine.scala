package controllers.searchEngine

import play.api.Play
import org.apache.lucene.util.Version
import org.apache.lucene.analysis.core.{WhitespaceAnalyzer, KeywordAnalyzer}
import org.apache.lucene.store.FSDirectory
import java.io.File
import org.apache.lucene.index.{Term, DirectoryReader}
import org.apache.lucene.search.{TermQuery, BooleanQuery, TopScoreDocCollector, IndexSearcher}
import org.apache.lucene.queryparser.classic.QueryParser
import org.apache.lucene.queryparser.flexible.standard.QueryParserUtil
import org.apache.lucene.search.BooleanClause.Occur
import org.apache.lucene.analysis.standard.StandardAnalyzer
import org.apache.lucene.analysis.util.CharArraySet

/**
 * Created by Aldo on 04/08/14.
 */
object Engine {

}

class Engine {
  val luceneVersion = Version.LUCENE_46
  val pathIndex = Play.current.configuration.getString("lucene.index").get
  val nPhrases = 5
  val nhits = 1000

  def search(str: String): List[Document] = {
    val analyzer = new WhitespaceAnalyzer(Version.LUCENE_46)
    val index = FSDirectory.open(new File(pathIndex))
    val reader = DirectoryReader.open(index)
    val searcher = new IndexSearcher(reader)
    val query = new QueryParser(Version.LUCENE_46, "content", analyzer).parse(str)
    val collector = TopScoreDocCollector.create(nhits, true)
    searcher.search(query, collector)
    val hits = collector.topDocs().scoreDocs
    println(hits.length + " " + str)
    val res = (for (i <- 0 until hits.length) yield {
      val docId = hits(i).doc
      val d = searcher.doc(docId)
      new Document(d.get("id"), d.get("text"))
    }).toList
    reader.close
    res
  }

  def getDocumentByID(mID:String, subID:Int): Document = getDocumentByID(mID + "#" + subID)

  def getDocumentByID(id: String): Document = {
    val analyzer = new KeywordAnalyzer
    val index = FSDirectory.open(new File(pathIndex))
    val reader = DirectoryReader.open(index)
    val searcher = new IndexSearcher(reader)
    val query = new QueryParser(luceneVersion, "id", analyzer).parse("\""+QueryParserUtil.escape(id)+"\"")
    val collector = TopScoreDocCollector.create(1, true)
    searcher.search(query, collector)
    val hits = collector.topDocs().scoreDocs
    val res = try {
      val docId = hits(0).doc
      val score = hits(0).score
      val d = searcher.doc(docId)
      new Document(id, d.get("text"))
    } catch {
      case e: Exception => new Document(id, "Error: document not found!")
    }
    reader.close
    res
  }

  def getSnippetByID(id: String): Snippet = {
    val ids = id.split("#")
    val mainID = ids(0)
    val subID = ids(1).toInt
    val nP = Math.floor(nPhrases/2).toInt
    val pre =
      (if(subID >= nP)
        (for(i <- (subID-nP) until subID) yield {getDocumentByID(mainID, i)}).toList else Nil)
    val post = (for(i <- subID+1 to (subID+nP)) yield {getDocumentByID(mainID, i)}).toList

    new Snippet(pre.map(_.content).mkString(" "), getDocumentByID(id).content, post.map(_.content).mkString(" "))
  }
}

class Document(val id: String, val content: String) {
  def getSnippet: Snippet = (new Engine).getSnippetByID(id)
}

class Snippet(val pre: String, val center: String, val post: String) {
  override def toString: String = pre + " " + center + " " + post
}
